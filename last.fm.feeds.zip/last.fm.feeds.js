/* CHRISKINCH.COM LAST FM FEED VIEWER */
$(document).ready(function(){
	//Getting the XML feed from Last.FM
	var settings = new Object();
	settings.username = 'chriskinch';
	settings.apikey = 'de5f3c80c1116bc51987f9aebc9fc3e9';
	settings.number = '15';
	settings.period = '3month'; //overall | 7day | 3month | 6month | 12month
	
	var config = new Object();
	config.size = 66;
	config.cols = 5;
	config.info = 2; //info size. Use 1 for normal size or 2 for double
	
	String.prototype.cleanup = function() {
	   return this.toLowerCase().replace(/[^a-zA-Z0-9]+/g, "-");
	}
	
	var image_id = (config.size<=34) ? 0 : (config.size <= 64) ? 1 : (config.size <= 126) ? 2 : 3;
	
	var lastUrl = 'http://ws.audioscrobbler.com/2.0/?method=user.gettopalbums&user=' + settings.username + '&api_key=' + settings.apikey + '&limit=' + settings.number + '&period=' + settings.period + '&format=json&callback=?';
	
	$.getJSON(lastUrl, function(data) {
		console.log(data);
		
		$('#lastfmrecords').attr('style', 'width:' + (config.size*config.cols) + ';');
		
		ul = $('<ul></ul>').appendTo('#lastfmrecords');
		
		$(data.topalbums.album).each(function(index) {
			
			var album_first 	= (index%config.cols == 0) ? ' album-first' : '';
			var album_last 		= ((index+1)%config.cols == 0) ? ' album-last' : '';
			var album_row 		= Math.ceil((index+1)/config.cols);
			var row_last 		= (album_row%(settings.number/config.cols) == 0) ? ' last-row' : '';
			
			var lfm_classes 	= 'album-' + (index+1) + ' album' + album_first + album_last + row_last;
			var lfm_artist		= data.topalbums.album[index].artist.name;
			var lfm_album		= data.topalbums.album[index].name;
			var lfm_plays		= data.topalbums.album[index].playcount;
			var lfm_href		= data.topalbums.album[index].url;
			var lfm_image		= data.topalbums.album[index].image[image_id]['#text'];
			
			var displace_top 	= (row_last != '' && config.info > 1) ? -config.size : '0';
			var displace_left	= (album_last != '' && config.info > 1) ? -config.size : '0';
						
			li = $('<li></li>')
				.attr('id', lfm_album.cleanup())
				.attr('class', lfm_classes)
				.attr('style', 'width:'+(config.size)+'px; height:'+(config.size)+'px;')
				.appendTo(ul);
					
			images = $('<img></img>')
					.attr('src', lfm_image)
					.attr('width', config.size)
					.attr('height', config.size)
					.appendTo(li);
					
			info = $('<span></span>')
					.attr('class', 'album-info')  
					.attr('style', 'width:'+(config.size*config.info)+'px; height:'+(config.size*config.info)+'px;' + ' top:' + displace_top + '; left:' + displace_left + ';')
					.appendTo(li);
			
			inner = $('<span></span>')
					.attr('class', 'album-info-inner')
					.appendTo(info);
			
			$('<p class="artist">' + lfm_artist + '</p>').appendTo(inner);
			$('<p class="album">' + lfm_album + '</p>').appendTo(inner);
			$('<p class="plays"><span>Plays:</span> ' + lfm_plays + '</p>').appendTo(inner);
			
			inner = $('<a></a>')
					.attr('class', 'rollover-area')
					.attr('href', lfm_href)
					.attr('style', 'width:'+(config.size)+'px; height:'+(config.size)+'px;')
					.attr('target', '_blank')
					.appendTo(li);
						
			$(info).hide();
		});
		
		$('#lastfmrecords .rollover-area').mouseenter(function() {
			$(this).addClass('active');
			$(this).parent().find('.album-info').delay(100).slideDown(200);
		});
		
		$('#lastfmrecords .rollover-area').mouseleave(function() {
			$(this).removeClass('active');
			$(this).parent().find('.album-info:hidden').stop(true);
			$(this).parent().find('.album-info').slideUp(200);
		});
		
		
	});
});